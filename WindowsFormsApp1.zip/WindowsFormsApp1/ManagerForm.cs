﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class ManagerForm : Form
    {
        private string currentUserName;
        private string currentUserRole;
        public ManagerForm(string userName, string role)
        {
            InitializeComponent();
            currentUserName = userName;
            currentUserRole = role;

            label1.Text = $"Пользователь: {userName} (Менеджер)";
        }

    }
}
