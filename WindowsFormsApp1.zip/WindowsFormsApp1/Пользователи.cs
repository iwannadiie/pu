﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Пользователи
    {
        public int Id_сотрудника {  get; set; }
        public string Роль_сотрудника { get; set; }
        public string ФИО { get; set; }
        public string Логин { get; set; }
        public string Пароль { get; set; }
    }
}
