﻿namespace WindowsFormsApp1
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.наименованиетовараDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.единицаизмеренияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.поставщикDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.производительDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.категориятовараDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.действующаяскидкаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.колвонаскладеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниетовараDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.товарBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toyStoreDataSet = new WindowsFormsApp1.ToyStoreDataSet();
            this.товарTableAdapter = new WindowsFormsApp1.ToyStoreDataSetTableAdapters.ТоварTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.номерзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.артикулзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датазаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датадоставкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.адреспунктавыдачиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОавторизированногоклиентаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.коддляполученияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусзаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.заказBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.toyStoreDataSet1 = new WindowsFormsApp1.ToyStoreDataSet1();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.заказTableAdapter = new WindowsFormsApp1.ToyStoreDataSet1TableAdapters.ЗаказTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toyStoreDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toyStoreDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.наименованиетовараDataGridViewTextBoxColumn,
            this.единицаизмеренияDataGridViewTextBoxColumn,
            this.ценаDataGridViewTextBoxColumn,
            this.поставщикDataGridViewTextBoxColumn,
            this.производительDataGridViewTextBoxColumn,
            this.категориятовараDataGridViewTextBoxColumn,
            this.действующаяскидкаDataGridViewTextBoxColumn,
            this.колвонаскладеDataGridViewTextBoxColumn,
            this.описаниетовараDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.товарBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(42, 126);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(557, 150);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // наименованиетовараDataGridViewTextBoxColumn
            // 
            this.наименованиетовараDataGridViewTextBoxColumn.DataPropertyName = "Наименование_товара";
            this.наименованиетовараDataGridViewTextBoxColumn.HeaderText = "Наименование_товара";
            this.наименованиетовараDataGridViewTextBoxColumn.Name = "наименованиетовараDataGridViewTextBoxColumn";
            // 
            // единицаизмеренияDataGridViewTextBoxColumn
            // 
            this.единицаизмеренияDataGridViewTextBoxColumn.DataPropertyName = "Единица_измерения";
            this.единицаизмеренияDataGridViewTextBoxColumn.HeaderText = "Единица_измерения";
            this.единицаизмеренияDataGridViewTextBoxColumn.Name = "единицаизмеренияDataGridViewTextBoxColumn";
            // 
            // ценаDataGridViewTextBoxColumn
            // 
            this.ценаDataGridViewTextBoxColumn.DataPropertyName = "Цена";
            this.ценаDataGridViewTextBoxColumn.HeaderText = "Цена";
            this.ценаDataGridViewTextBoxColumn.Name = "ценаDataGridViewTextBoxColumn";
            // 
            // поставщикDataGridViewTextBoxColumn
            // 
            this.поставщикDataGridViewTextBoxColumn.DataPropertyName = "Поставщик";
            this.поставщикDataGridViewTextBoxColumn.HeaderText = "Поставщик";
            this.поставщикDataGridViewTextBoxColumn.Name = "поставщикDataGridViewTextBoxColumn";
            // 
            // производительDataGridViewTextBoxColumn
            // 
            this.производительDataGridViewTextBoxColumn.DataPropertyName = "Производитель";
            this.производительDataGridViewTextBoxColumn.HeaderText = "Производитель";
            this.производительDataGridViewTextBoxColumn.Name = "производительDataGridViewTextBoxColumn";
            // 
            // категориятовараDataGridViewTextBoxColumn
            // 
            this.категориятовараDataGridViewTextBoxColumn.DataPropertyName = "Категория_товара";
            this.категориятовараDataGridViewTextBoxColumn.HeaderText = "Категория_товара";
            this.категориятовараDataGridViewTextBoxColumn.Name = "категориятовараDataGridViewTextBoxColumn";
            // 
            // действующаяскидкаDataGridViewTextBoxColumn
            // 
            this.действующаяскидкаDataGridViewTextBoxColumn.DataPropertyName = "Действующая_скидка";
            this.действующаяскидкаDataGridViewTextBoxColumn.HeaderText = "Действующая_скидка";
            this.действующаяскидкаDataGridViewTextBoxColumn.Name = "действующаяскидкаDataGridViewTextBoxColumn";
            // 
            // колвонаскладеDataGridViewTextBoxColumn
            // 
            this.колвонаскладеDataGridViewTextBoxColumn.DataPropertyName = "Кол_во_на_складе";
            this.колвонаскладеDataGridViewTextBoxColumn.HeaderText = "Кол_во_на_складе";
            this.колвонаскладеDataGridViewTextBoxColumn.Name = "колвонаскладеDataGridViewTextBoxColumn";
            // 
            // описаниетовараDataGridViewTextBoxColumn
            // 
            this.описаниетовараDataGridViewTextBoxColumn.DataPropertyName = "Описание_товара";
            this.описаниетовараDataGridViewTextBoxColumn.HeaderText = "Описание_товара";
            this.описаниетовараDataGridViewTextBoxColumn.Name = "описаниетовараDataGridViewTextBoxColumn";
            // 
            // товарBindingSource
            // 
            this.товарBindingSource.DataMember = "Товар";
            this.товарBindingSource.DataSource = this.toyStoreDataSet;
            // 
            // toyStoreDataSet
            // 
            this.toyStoreDataSet.DataSetName = "ToyStoreDataSet";
            this.toyStoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // товарTableAdapter
            // 
            this.товарTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерзаказаDataGridViewTextBoxColumn,
            this.артикулзаказаDataGridViewTextBoxColumn,
            this.датазаказаDataGridViewTextBoxColumn,
            this.датадоставкиDataGridViewTextBoxColumn,
            this.адреспунктавыдачиDataGridViewTextBoxColumn,
            this.фИОавторизированногоклиентаDataGridViewTextBoxColumn,
            this.коддляполученияDataGridViewTextBoxColumn,
            this.статусзаказаDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.заказBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(42, 304);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(557, 150);
            this.dataGridView2.TabIndex = 4;
            // 
            // номерзаказаDataGridViewTextBoxColumn
            // 
            this.номерзаказаDataGridViewTextBoxColumn.DataPropertyName = "Номер_заказа";
            this.номерзаказаDataGridViewTextBoxColumn.HeaderText = "Номер_заказа";
            this.номерзаказаDataGridViewTextBoxColumn.Name = "номерзаказаDataGridViewTextBoxColumn";
            // 
            // артикулзаказаDataGridViewTextBoxColumn
            // 
            this.артикулзаказаDataGridViewTextBoxColumn.DataPropertyName = "Артикул_заказа";
            this.артикулзаказаDataGridViewTextBoxColumn.HeaderText = "Артикул_заказа";
            this.артикулзаказаDataGridViewTextBoxColumn.Name = "артикулзаказаDataGridViewTextBoxColumn";
            // 
            // датазаказаDataGridViewTextBoxColumn
            // 
            this.датазаказаDataGridViewTextBoxColumn.DataPropertyName = "Дата_заказа";
            this.датазаказаDataGridViewTextBoxColumn.HeaderText = "Дата_заказа";
            this.датазаказаDataGridViewTextBoxColumn.Name = "датазаказаDataGridViewTextBoxColumn";
            // 
            // датадоставкиDataGridViewTextBoxColumn
            // 
            this.датадоставкиDataGridViewTextBoxColumn.DataPropertyName = "Дата_доставки";
            this.датадоставкиDataGridViewTextBoxColumn.HeaderText = "Дата_доставки";
            this.датадоставкиDataGridViewTextBoxColumn.Name = "датадоставкиDataGridViewTextBoxColumn";
            // 
            // адреспунктавыдачиDataGridViewTextBoxColumn
            // 
            this.адреспунктавыдачиDataGridViewTextBoxColumn.DataPropertyName = "Адрес_пункта_выдачи";
            this.адреспунктавыдачиDataGridViewTextBoxColumn.HeaderText = "Адрес_пункта_выдачи";
            this.адреспунктавыдачиDataGridViewTextBoxColumn.Name = "адреспунктавыдачиDataGridViewTextBoxColumn";
            // 
            // фИОавторизированногоклиентаDataGridViewTextBoxColumn
            // 
            this.фИОавторизированногоклиентаDataGridViewTextBoxColumn.DataPropertyName = "ФИО_авторизированного_клиента";
            this.фИОавторизированногоклиентаDataGridViewTextBoxColumn.HeaderText = "ФИО_авторизированного_клиента";
            this.фИОавторизированногоклиентаDataGridViewTextBoxColumn.Name = "фИОавторизированногоклиентаDataGridViewTextBoxColumn";
            // 
            // коддляполученияDataGridViewTextBoxColumn
            // 
            this.коддляполученияDataGridViewTextBoxColumn.DataPropertyName = "Код_для_получения";
            this.коддляполученияDataGridViewTextBoxColumn.HeaderText = "Код_для_получения";
            this.коддляполученияDataGridViewTextBoxColumn.Name = "коддляполученияDataGridViewTextBoxColumn";
            // 
            // статусзаказаDataGridViewTextBoxColumn
            // 
            this.статусзаказаDataGridViewTextBoxColumn.DataPropertyName = "Статус_заказа";
            this.статусзаказаDataGridViewTextBoxColumn.HeaderText = "Статус_заказа";
            this.статусзаказаDataGridViewTextBoxColumn.Name = "статусзаказаDataGridViewTextBoxColumn";
            // 
            // заказBindingSource
            // 
            this.заказBindingSource.DataMember = "Заказ";
            this.заказBindingSource.DataSource = this.toyStoreDataSet1;
            // 
            // toyStoreDataSet1
            // 
            this.toyStoreDataSet1.DataSetName = "ToyStoreDataSet1";
            this.toyStoreDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(324, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.BurlyWood;
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Назад";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // заказTableAdapter
            // 
            this.заказTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.BurlyWood;
            this.button2.Location = new System.Drawing.Point(125, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Удалить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 470);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.товарBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toyStoreDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toyStoreDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private ToyStoreDataSet toyStoreDataSet;
        private System.Windows.Forms.BindingSource товарBindingSource;
        private ToyStoreDataSetTableAdapters.ТоварTableAdapter товарTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиетовараDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаизмеренияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn поставщикDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn производительDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn категориятовараDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn действующаяскидкаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn колвонаскладеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниетовараDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private ToyStoreDataSet1 toyStoreDataSet1;
        private System.Windows.Forms.BindingSource заказBindingSource;
        private ToyStoreDataSet1TableAdapters.ЗаказTableAdapter заказTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn артикулзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датазаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датадоставкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn адреспунктавыдачиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОавторизированногоклиентаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn коддляполученияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn статусзаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button2;
    }
}