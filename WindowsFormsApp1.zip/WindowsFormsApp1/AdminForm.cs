﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AdminForm : Form
    {
        private string currentUserName;
        private string currentUserRole;

        public AdminForm(string userName, string role)
        {
            InitializeComponent();
            currentUserName = userName;
            currentUserRole = role;

            label1.Text = $"Пользователь: {userName} (Администратор)";

            // Автоматическая загрузка данных
            LoadProducts();
            LoadOrders();
        }

        private void LoadProducts()
        {
            string connectionString = @"Data Source=DESKTOP;Initial Catalog=ToyStore;Integrated Security=True";
            string query = @"SELECT * FROM Товар";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки товаров: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadOrders()
        {
            string connectionString = @"Data Source=DESKTOP;Initial Catalog=ToyStore;Integrated Security=True";

            // Проверяем, существует ли таблица Заказы
            string query = "SELECT * FROM Заказ";


                using (SqlConnection conn = new SqlConnection(connectionString))
                {

                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView2.DataSource = dt;
                    }
                }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadProducts();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Close();
        }

        // Кнопка "Удалить" - удаляет выбранную строку
        private void button2_Click(object sender, EventArgs e)
        {
            // Проверяем, есть ли выделенная строка в первой таблице
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string article = dataGridView1.SelectedRows[0].Cells["Артикул_заказа"].Value.ToString();

                DialogResult result = MessageBox.Show("Удалить выбранный товар?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string connectionString = @"Data Source=DESKTOP;Initial Catalog=ToyStore;Integrated Security=True";
                    string query = "DELETE FROM Товар WHERE Артикул_заказа = @Article";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@Article", article);
                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadProducts(); // Обновляем таблицу товаров
                    MessageBox.Show("Товар удален!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return;
            }

            // Проверяем, есть ли выделенная строка во второй таблице
            if (dataGridView2.SelectedRows.Count > 0)
            {
                // Используем индекс 0 (первый столбец) вместо имени
                string orderId = dataGridView2.SelectedRows[0].Cells[0].Value.ToString();

                DialogResult result = MessageBox.Show("Удалить выбранный заказ?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    string connectionString = @"Data Source=DESKTOP;Initial Catalog=ToyStore;Integrated Security=True;User ID=sa;Password=123456";
                    string query = "DELETE FROM Заказ WHERE Номер_заказа = @OrderId";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@OrderId", orderId);
                            conn.Open();
                            cmd.ExecuteNonQuery();
                        }
                    }

                    LoadOrders(); // Обновление таблицы заказов
                    MessageBox.Show("Заказ удален!", "Успех",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                return;
            }

            // Если ничего не выбрано
            MessageBox.Show("Выберите строку для удаления!", "Внимание",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}