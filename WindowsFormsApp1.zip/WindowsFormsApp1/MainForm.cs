﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        private string currentUserName;
        private string currentUserRole;

        // Конструктор
        public MainForm(string userName, string role)
        {
            InitializeComponent();
            currentUserName = userName;
            currentUserRole = role;

            label1.Text = $"Пользователь: {userName} ({role})";

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            this.товарTableAdapter.Fill(this.toyStoreDataSet.Товар);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Close();
        }

        private void LoadProducts()
        {
            string connectionString = @"Data Source=DESKTOP;Initial Catalog=ToyStore;Integrated Security=True";
            string query = @"SELECT * FROM Товар";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlDataAdapter adapter = new SqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки товаров: " + ex.Message, "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadProducts();
        }
    }
}