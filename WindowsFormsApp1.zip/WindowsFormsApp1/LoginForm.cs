﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();
            string password = textBox2.Text;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                label5.Text = "Введите логин и пароль!";
                return;
            }

            string connectionString = @"Data Source=DESKTOP;Initial Catalog=ToyStore;Integrated Security=True";
            string query = "SELECT ФИО, Роль_сотрудника FROM Пользователи WHERE Логин = @Login AND Пароль = @Password";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Login", login);
                        cmd.Parameters.AddWithValue("@Password", password);
                        conn.Open();
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.Read())
                        {
                            string userName = reader["ФИО"].ToString();
                            string role = reader["Роль_сотрудника"].ToString();
                            reader.Close();

                            OpenFormByRole(userName, role);
                        }
                        else
                        {
                            label5.Text = "Неверный логин или пароль!";
                            textBox2.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                label5.Text = "Ошибка БД: " + ex.Message;
            }
        }

        private void OpenFormByRole(string userName, string role)
        {
            Form form = null;

            switch (role)
            {
                case "Администратор":
                    form = new AdminForm(userName, role);
                    break;
                case "Менеджер":
                    form = new ManagerForm(userName, role);
                    break;
                case "Авторизированный клиент":
                    form = new MainForm(userName, role); 
                    break;
                default:
                    form = new GuestForm();
                    break;
            }

            form.Show();
            this.Hide();
        }

        // Кнопка "Войти как гость"
        private void button2_Click(object sender, EventArgs e)
        {
            GuestForm guestForm = new GuestForm();
            guestForm.Show();
            this.Hide();
        }
    }
}